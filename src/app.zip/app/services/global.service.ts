import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
@Injectable()
export class GlobalService {
 

    constructor() {
     
    }
  
}