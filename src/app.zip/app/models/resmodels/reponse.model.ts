export class ResponseModel{
    Data:any;
    Message:string;
    ResCode:number;
}