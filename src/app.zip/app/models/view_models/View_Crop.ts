export class View_cropyield{
    constructor(){

    }
    Crop_Type_Code:string;
    Crop_Type:string;
    Crop_Yield:number;
    Loan_ID:number;
    Practice_Type_Code:string;
    APH:number;
}