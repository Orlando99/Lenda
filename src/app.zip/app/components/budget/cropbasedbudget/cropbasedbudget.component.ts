import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cropbasedbudget',
  templateUrl: './cropbasedbudget.component.html',
  styleUrls: ['./cropbasedbudget.component.scss']
})
export class CropbasedbudgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
