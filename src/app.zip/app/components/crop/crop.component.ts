import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crop',
  templateUrl: './crop.component.html',
  styleUrls: ['./crop.component.scss']
})
export class CropComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
